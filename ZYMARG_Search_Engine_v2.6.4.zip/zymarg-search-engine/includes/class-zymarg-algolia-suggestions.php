<?php
/**
 * Local text-suggestions engine (2.6.4).
 *
 * Builds a lightweight, text-only suggestion list (product titles — first 5
 * words — plus product-category names and vendor store names) from the site's
 * own data, caches it, and serves it via a public REST endpoint.
 *
 * The search bar dropdown filters this list locally in the browser, so
 * typing costs ZERO Algolia operations. Algolia is only queried when the
 * shopper commits to the full results page (presses Enter / "See all results").
 *
 * @package ZymargAlgolia
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Zymarg_Algolia_Suggestions {

	const OPTION       = 'zymarg_algolia_suggestions';
	const BUILT_OPTION = 'zymarg_algolia_suggestions_built';
	const REBUILD_HOOK = 'zymarg_algolia_build_suggestions';

	public function __construct() {
		// Public REST endpoint the dropdown fetches once (browser-cached).
		add_action( 'rest_api_init', array( $this, 'register_route' ) );

		// Rebuild worker (async / cron).
		add_action( self::REBUILD_HOOK, array( $this, 'build' ) );
		// Daily backstop — piggybacks the existing cleanup cron.
		add_action( 'zymarg_algolia_cleanup_cron', array( $this, 'build' ) );

		// Invalidate + schedule a rebuild when catalogue data changes.
		add_action( 'save_post', array( $this, 'on_post_change' ), 20, 1 );
		add_action( 'deleted_post', array( $this, 'on_post_change' ), 20, 1 );
		add_action( 'trashed_post', array( $this, 'on_post_change' ), 20, 1 );
		add_action( 'untrashed_post', array( $this, 'on_post_change' ), 20, 1 );

		foreach ( array( 'created_product_cat', 'edited_product_cat', 'delete_product_cat' ) as $h ) {
			add_action( $h, array( $this, 'schedule_rebuild' ) );
		}
		foreach ( array( 'profile_update', 'user_register', 'deleted_user' ) as $h ) {
			add_action( $h, array( $this, 'schedule_rebuild' ) );
		}
	}

	/* ─── REST ────────────────────────────────────────────────────── */

	public function register_route() {
		register_rest_route(
			'zymarg-algolia/v1',
			'/suggestions',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => array( $this, 'rest_suggestions' ),
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public function rest_suggestions() {
		$data     = $this->get_data();
		$response = new WP_REST_Response( $data, 200 );
		// Cache in the browser + any CDN for an hour; rebuilds bump the payload.
		$response->header( 'Cache-Control', 'public, max-age=3600' );
		return $response;
	}

	/* ─── DATA ────────────────────────────────────────────────────── */

	/**
	 * Cached list, building it once if the cache is empty.
	 *
	 * @return array
	 */
	public function get_data() {
		$data = get_option( self::OPTION, null );
		if ( ! is_array( $data ) ) {
			$data = $this->build();
		}
		return $data;
	}

	/**
	 * Build (and cache) the suggestion list.
	 *
	 * @return array List of { t: text, y: type, u?: url }.
	 */
	public function build() {
		global $wpdb;

		$items = array();
		$seen  = array(); // lowercased text => true (dedupe)

		$push = function ( $text, $type, $url = '' ) use ( &$items, &$seen ) {
			$text = trim( wp_strip_all_tags( (string) $text ) );
			if ( '' === $text ) {
				return;
			}
			$key = strtolower( $text ) . '|' . $type;
			if ( isset( $seen[ $key ] ) ) {
				return;
			}
			$seen[ $key ] = true;
			$row = array( 't' => $text, 'y' => $type );
			if ( '' !== $url ) {
				$row['u'] = $url;
			}
			$items[] = $row;
		};

		/* Products — first 5 words of the title. */
		$cap = (int) apply_filters( 'zymarg_algolia_suggestions_product_cap', 0 ); // 0 = no cap.
		$limit_sql = $cap > 0 ? ' LIMIT ' . $cap : '';
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$titles = $wpdb->get_col(
			"SELECT post_title FROM {$wpdb->posts}
			 WHERE post_type = 'product' AND post_status = 'publish' AND post_title <> ''
			 ORDER BY post_modified DESC" . $limit_sql
		);
		// phpcs:enable
		foreach ( (array) $titles as $title ) {
			$words = preg_split( '/\s+/', trim( $title ) );
			$push( implode( ' ', array_slice( $words, 0, 5 ) ), 'product' );
		}

		/* Product categories — name + archive link. */
		if ( taxonomy_exists( 'product_cat' ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => 'product_cat',
					'hide_empty' => false,
					'number'     => 0,
				)
			);
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$link = get_term_link( $term );
					$push( $term->name, 'category', is_wp_error( $link ) ? '' : $link );
				}
			}
		}

		/* Vendors — Dokan store name + store URL. */
		$sellers = get_users(
			array(
				'role__in' => array( 'seller', 'vendor' ),
				'fields'   => array( 'ID', 'display_name' ),
				'number'   => (int) apply_filters( 'zymarg_algolia_suggestions_vendor_cap', 2000 ),
			)
		);
		foreach ( $sellers as $u ) {
			$profile = get_user_meta( $u->ID, 'dokan_profile_settings', true );
			$name    = ( is_array( $profile ) && ! empty( $profile['store_name'] ) ) ? $profile['store_name'] : $u->display_name;
			$url     = function_exists( 'dokan_get_store_url' ) ? dokan_get_store_url( $u->ID ) : '';
			$push( $name, 'vendor', $url );
		}

		/**
		 * Filter the final suggestion list before it is cached/served.
		 *
		 * @param array $items List of { t, y, u? }.
		 */
		$items = apply_filters( 'zymarg_algolia_suggestions', $items );

		update_option( self::OPTION, $items, false );
		update_option( self::BUILT_OPTION, time(), false );

		return $items;
	}

	/* ─── INVALIDATION ────────────────────────────────────────────── */

	/**
	 * Only react to product changes (ignore every other post type).
	 *
	 * @param int $post_id Post ID.
	 */
	public function on_post_change( $post_id ) {
		if ( 'product' === get_post_type( $post_id ) ) {
			$this->schedule_rebuild();
		}
	}

	/**
	 * Schedule a single debounced rebuild. Prefers Action Scheduler
	 * (bundled with WooCommerce); falls back to WP-Cron. Never rebuilds
	 * synchronously on the save request.
	 */
	public function schedule_rebuild() {
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_enqueue_async_action' ) ) {
			if ( ! as_has_scheduled_action( self::REBUILD_HOOK, array(), 'zymarg-algolia' ) ) {
				as_enqueue_async_action( self::REBUILD_HOOK, array(), 'zymarg-algolia' );
			}
			return;
		}
		if ( ! wp_next_scheduled( self::REBUILD_HOOK ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::REBUILD_HOOK );
		}
	}
}
